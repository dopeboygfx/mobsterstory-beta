<?
include 'header.php';
?>
<thead>
<tr>
<th>Gang List</th>
</tr>
</thead>
<tr><td>
<table class="inverted ui five unstackable column small compact table">
	<tr>
		<td>Rank</td>
		<td>Gang</td>
		<td>Members</td>
		<td>Leader</td>
		<td>Level</td>
	</tr>
<?php

$result = $GLOBALS['pdo']->query('SELECT * FROM `gangs` ORDER BY `exp` DESC');
$result = $result->fetchAll(PDO::FETCH_ASSOC);

$rank = 1;
foreach($result as $line){
	$result2 = $GLOBALS['pdo']->prepare('SELECT * FROM `grpgusers` WHERE `username` = ?');
	$result2->execute(array($line['leader']));
	$worked2 = $result2->fetch(PDO::FETCH_ASSOC);

	$gang = New Gang($line['id']);
	$gang_leader = new User($worked2['id']);

	echo "
	<tr>
	<td>".$rank."</td>
	<td>".$gang->formattedname."</td>
	<td>".$gang->members."</td>
	<td>".$gang_leader->formattedname."</td>
	<td>".$gang->level."</td>
	</tr>
	";

	$rank++;
}
?>
</table>
</td></tr>
<?
include 'footer.php';
?>
