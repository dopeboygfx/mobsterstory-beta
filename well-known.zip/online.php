<?
include 'header.php';
echo '
	<thead>
    <tr><th>Users Online In The Last 5 Minutes</th>
	</tr>
	</thead>
	';

$result = $GLOBALS['pdo']->query("SELECT * FROM `grpgusers` ORDER BY `lastactive` DESC");
$result = $result->fetchAll(PDO::FETCH_ASSOC);

echo '<tr><td>';
foreach($result as $line){
		$secondsago = time()-$line['lastactive'];
		if ($secondsago<=300) {
			$user_online = new User($line['id']);
			echo "<div>".$user_online->formattedname . " ". howlongago($user_online->lastactive)."</div>";
		}
	}
echo '</td></tr>';

include 'footer.php'
?>
