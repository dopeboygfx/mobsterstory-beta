<?

session_start();

include 'dbcon.php';

include 'classes.php';

//$time = date(F." ".d.", ".Y." ".g.":".i.":".sa,time());

$time = date("m/d/Y h:i:s a", time());
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>

<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129078539-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129078539-3');
</script>
<title>Mobster Story 2018</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <link rel="stylesheet" type="text/css" href="../dist/semantic.css">
  <link rel="stylesheet" type="text/css" href="homepage.css">

  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.js"></script>
  <script src="../dist/semantic.js"></script>
  <script src="homepage.js"></script>

  <div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.2&appId=921602524699801&autoLogAppEvents=1';
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>

  <link rel="stylesheet" href="style.css" type="text/css" />
</head>



<body>
	<table bgcolor="#1E1E1E" border="0" cellspacing="0" cellpadding="0" width="100%">
	<tr>
	<td>
	<div class="ui inverted menu"><a class="item">Server Time: <?= $time; ?></a></div>
	</td>
	</tr>
	<tr>
    <td colspan="3" class="pos1" height="55" valign="middle">
      <div class="topbox">
      	<table width='800' height='150'>
	  		<tr>
	  			<td width="50%">
	  				<img src="images/logo3.png" width="800" height="150">

	  			</td>



	  		</tr>

	</table>



      </div>

    </td>

  </tr>

  <tr>

    <td>

      <table width="100%" border="0" cellpadding="0" cellspacing="0">

        <tr>

          <td valign="top" width="150"> <br />

		  	<div>


		<div class="ui vertical inverted menu" width="100px;">
		  <div class="item">
		    <div class="header">Menu</div>
		    <div class="menu">
					<a class="item" a href="index.php">Home<i class="home icon"></i></a>
					<a class="item" href="login.php">Login</a>
					<a class="item" href="register.php">Register</a>
					<a class="item" href="forgot.php">Account Recovery</a>
		    </div>
		  </div>
		</div>		  
		

		 </ul>



			  <br />

            </div>

          </td>

          <td valign="top"> <br />

            <table border="0" cellspacing="0" cellpadding="0" width="100%">

              <tr>

                <td width="10"></td>

                <td valign="top" class="mainbox">

<table class="inverted ui five unstackable column small compact table">