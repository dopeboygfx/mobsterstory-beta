

</table>



                </td>

              </tr>

            </table>

			<br />

          </td>

        </tr>

      </table>

    </td>

  </tr>

</table>



<table width="870" class="inverted ui five unstackable column small compact table">

<tr>

    <td height="20" colspan="2" align="center" >

<?php

$stats = new User_Stats("bang");

?>





     | <a href='citizens.php'><?php echo $stats->playerstotal; ?> Total Mobsters</a>

			 &nbsp; | &nbsp;

			<a href='online.php'><?php echo $stats->playersloggedin; ?> Mobsters Online</a>

			 &nbsp; | &nbsp;

			<a href='24hour.php'><?php echo $stats->playersonlineinlastday; ?> Mobsters Online (24 Hours)</a> |<br>

	<?

	$endtime = microtime_float();

	$totaltime= round($endtime - $starttime,2);

	echo "This page was generated in " . $totaltime . " seconds";

?>

<br />&copy; Mobster Story 2018 | Designed By: <a href="http://instagram.com/twolucky.img">Two Lucky</a>



    </td>

  </tr>

</table>

</body>

</body>

</html>
<?
ob_end_flush();
?>