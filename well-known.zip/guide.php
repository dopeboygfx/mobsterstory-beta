<?
include 'header.php';
?>
<td class="contenthead" colspan="2">Guide</td></tr><tr>	<td class="contentcontent">	<table width="100%">

<tr>
<th>Welcome to the Mobster Story Guide</th>
</tr>
<tr>
<td style='text-align: center;'>You start as a character, a mobster</td>
</tr>
<tr>
<td style='text-align: center;'>New Jersey is the city you start in. Explore the <a href="city.php">City</a> page</td>
</tr>
</td>

<?


include 'footer.php';
?>


	