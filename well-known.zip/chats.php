<?php
print "<meta http-equiv='refresh' content='3; url=chats.php'>
<body bgcolor='#333'><center>
<font face='verdana' size='2' color='gold'>";
if(file_exists("chatbox.txt"))
{
$f=file_get_contents("chatbox.txt");
$f=strip_tags($f);
$f=str_replace("/n", "<br />", $f);
} else {
$f="Chat isn't configured right. Remember to CHMOD the file chatbox.txt to 777. Thanks.";
}
print $f;
?>
</font></center></body>