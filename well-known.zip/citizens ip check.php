<?
include 'header.php';
echo '<tr><td class="contenthead">Total Users</td></tr>';
echo '<tr><td class="contentcontent">';

$result = $GLOBALS['pdo']->query('SELECT * FROM `grpgusers` ORDER BY `ip` ASC');

foreach($result as $line){
	$result1 = $GLOBALS['pdo']->prepare('SELECT * FROM `grpgusers` WHERE `ip` = ?');
	$result1->execute(array($line['ip']));
	if(count($result1->fetchAll(PDO::FETCH_NUM)) > 1){
		$user_online = new User($line['id']);
		echo "<div>".$user_online->ip.".)".$user_online->formattedname."</div>";
	}
}
echo "</td></tr>";
include 'footer.php'
?>
