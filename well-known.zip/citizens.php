<?
include 'header.php';
echo '
<thead>
<tr>
<th>Total Users</th>
</tr>
</thead>
';
echo '<tr><td>';
$result = $GLOBALS['pdo']->query("SELECT * FROM `grpgusers` ORDER BY `id` ASC")->fetchAll(PDO::FETCH_ASSOC);

foreach($result as $line){
	$secondsago = time()-$line['lastactive'];
	$user_online = new User($line['id']);
	echo "<div>".$user_online->id.".) ".$user_online->formattedname."</div>";
}

echo "</td></tr>";
include 'footer.php'
?>
