xdescribe("UI Tab", function() {

  moduleTests({
    module    : 'tab',
    element   : '.ui.menu .item',
    singleton : true
  });

});