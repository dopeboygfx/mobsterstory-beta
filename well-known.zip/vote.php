<?php
include 'header.php';
?>
 <thead>
    <tr>
	<th>Vote</th>
  	</tr>
 </thead>
<tr><td>
<a href="https://www.browsermmorpg.com/vote.php?id=1578" target="_blank" title="Vote at Browser MMORPG">
<img src="https://www.browsermmorpg.com/img/vote_banner.gif" alt="Vote at Browser MMORPG" /></a>
</br>

<a href="http://www.mmorpg100.com/in.php?id=8662">
<img src="http://www.mmorpg100.com/images/mmorpg_100.gif" width="88" height="53" border="0" alt="free mmorpg 100 online rpg chart"></a>
</br>

<a href="http://toponlinemmorpg.com/vote.php?id=453" target="_blank" title="Vote at Top Online MMORPG">
<img src="http://toponlinemmorpg.com/img/vote_banner.gif" alt="Vote at Top Online MMORPG" /></a>
</br>
Rank 48
<a href="http://mpogtop.com/in/1545729974" target="_blank">
<img src="http://mpogtop.com/images/mpogtop8831.jpg" alt="MPOGTOP" title="Come to MPOG TOP - Multiplayer Online Sites List MMORPG and vote for this site!" border="0" /></a> 
</br>

<a href="http://top50.onrpg.com/">
<img src="The location where the image is saved on your server" alt="Free MMORPG / MMOG Top 50 Games / OnRPG.com" border="0" /></a>
</br> 

<a href='http://www.top100arena.com/mmorpg/' title='MMORPG Games'>
<img src='http://www.top100arena.com/hit.asp?id=94803&c=mmorpg&t=1' alt='MMORPG Games' width='88px' height='31px' border='0'></a>
</br>

<a href="http://bbogd.com/vote/mobster-story-">Vote For Mobster Story</a>
</br>
<a href="http://www.topwebgames.com/game/8142"> Vot For Mobster Story via TWG.COM</a>
</br>
</td></tr>
<?php
include 'footer.php';
?>