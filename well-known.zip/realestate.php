<?
include 'header.php';

$result = $GLOBALS['pdo']->prepare('SELECT * FROM `cities` WHERE `id` = ?');
$result->execute(array($user_class->city));
$worked = $result->fetch(PDO::FETCH_ASSOC);

if ($_POST['buyland']){
    $price = $worked['landprice'];
	$amount = $worked['landleft'];
 	$totalcost = $price * $_POST['amount'];
 	$newlandtotal = $amount - $_POST['amount'];
 	$currentland = Check_Land($user_class->city, $user_class->id);

	$error = ($_POST['amount'] > $amount) ? "There is not that much land available." : $error;
	$error = ($_POST['amount'] < 1) ? "Please enter a valid amount of land." : $error;
	$error = ($totalcost > $user_class->money) ? "You don't have enough money." : $error;

	if (isset($error)){
		echo Message($error);
		include 'footer.php';
		die();
	}
	
	echo Message("You have bought ".$_POST['amount']." acres of land in ".$user_class->cityname." for $".$totalcost);
	Give_Land($user_class->city, $user_class->id, $_POST['amount']);
	
	$newmoney = $user_class->money - $totalcost;

	$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `money` = ? WHERE `id` = ?');
	$result->execute(array($newmoney, $user_class->id));

	$user_class = new User($_SESSION['id']);

	$result = $GLOBALS['pdo']->prepare('UPDATE `cities` SET `landleft` = ? WHERE `id` = ?');
	$result->execute(array($newlandtotal, $user_class->city));
}

$result = $GLOBALS['pdo']->prepare('SELECT * FROM `cities` WHERE `id` = ?');
$result->execute(array($user_class->city));
$worked = $result->fetch(PDO::FETCH_ASSOC);
?>
<thead>
<tr>
<th>Real Estate Agency</th>
</tr>
</thead>
<tr><td>
Welcome to REAG! If we have any land left available, you can purchase it from here.
</td></tr>
<tr><td>
Land available from REAG in <?= $user_class->cityname ?>: <?= $worked['landleft'] ?> acres
<?
if($worked['landleft'] != 0){
	echo "<form method='post'><input type='text' name='amount' size='3' maxlength='20' value='".$worked['landleft']."'> <input type='submit' name='buyland' value='Buy Land At $".$worked['landprice']." Per Acre'></post>";
}
?>
</td></tr>
<?
include 'footer.php';
?>
