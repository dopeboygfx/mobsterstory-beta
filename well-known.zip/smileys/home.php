<?
session_start();

include 'dbcon.php';

include 'classes.php';

$time = date(F." ".d.", ".Y." ".g.":".i.":".sa,time());

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>

<head>

<title>The Mafia Kings</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<LINK REL=StyleSheet HREF="homestyle.css" TYPE="text/css" MEDIA=screen>

<link REL="SHORTCUT ICON" HREF="images/favicon.gif">

</head>
<body background="images/background2.gif">
<table bgcolor="#000000" border="0" cellspacing="0" cellpadding="0" width="100%" height="500px" style='background-image: url("images/main.png"); background-attachment:scroll; background-position: right; background-repeat: no-repeat;'>
  <tr>
    <td valign="top">	
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="top">
            <table border="0" cellspacing="0" cellpadding="0" width="100%">
              <tr>
                <td valign="top" class="mainbox">
<table class="content" border="0" width="100%" height="100%">

<tr valign="top">
<td width="70%" valign="top">
  <div align="center">
    <table width="57%" border="0" cellspacing="14">
      
      <tr><td align="center"><h1><b>The Mafia Kings</b></h1></td></tr>
      
      <tr>
        <td align="center">
          <table width="100%" cellpadding="7" align="center" style="border:1px solid #333333;background-color:#111111;font-size:12px;">
            <tr>
              <td align="center">Welcome to The Mafia Kings, a FREE text RPG your aim is to survive in this crazy world where crime never ends! </td></tr>
            </table>
          </td>
        
        <tr>
          <td align="center">
            <table width="87%" cellpadding="7" cellspacing="0" align="center" style="background-color:#111111;font-size:12px;" class="table">
              <tr style="background-color:#1A1A1A;">
                <td align="center"  class="td"><b>Username</b></td>
                <td align="center" class="td"><b>Password</b></td>
                <td align="center" class="td">&nbsp;</td>
                </tr>
              <tr>
                <form method="post" action="login.php">
                  <td align="center" class="td"><input type="text" name="username" size="17" STYLE="background-color:#222222; border: 1px solid #444444; color:#FFFFFF" /></td>
                  <td align="center" class="td"><input type="password" name="password" size="17" STYLE="background-color:#222222; border: 1px solid #444444; color:#FFFFFF" /></td>
                  <td align="center" class="td"><input type="submit" name="login" value="Login" STYLE="background-color:#222222; border: 1px solid #444444; color:#FFFFFF" /></td>
                  </form>
                </tr>
              </table>
            </td>
          
          <tr>
            <td align="center">
              <table width="100%" cellpadding="7" cellspacing="0" align="center" style="background-color:#111111;font-size:12px;" class="table">
                <tr style="background-color:#1A1A1A;">
                  <td align="center" class="td"><b>Members</b></td>
                  <td align="center" class="td"><b>Online</b></td>
                  <td align="center" class="td"><b>Register</b></td>
                  <td align="center" class="td"><b>Login</b></td>
                  </tr>
                
                <?php
$result = mysql_query("SELECT * FROM `grpgusers`");
$totalmembers = mysql_num_rows($result);

$result2 = mysql_query("SELECT * FROM `grpgusers`");
$online = 0;
while($line = mysql_fetch_array($result2, MYSQL_ASSOC)) {
$secondsago = time()-$line['lastactive'];
if ($secondsago<=900) {
$online ++;
}
}
?>
                
                <tr>
                  <td align="center" class="td"><?php echo prettynum($totalmembers); ?></td>
                  <td align="center" class="td"><?php echo prettynum($online); ?></td>
                  <td align="center" class="td"><a href="register.php">Register</a></td>
                  <td align="center" class="td"><a href="login.php">Login</a></td>
                  </tr>
                </table>
              </td>
            
            
            </tr>
      <tr>
        <td style="font-size: 11px;" align="center">Our website is best viewed in firefox. You can get it below.<br /><a href="http://www.mozilla.com/" target="_blank">Download Firefox Here</a></td>
        </tr>
      <tr><td height="5px"></td></tr>
      <tr>
        <td style="font-size: 11px;" align="center"><iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FMafia-Warfare%2F137604582946864&amp;layout=standard&amp;show_faces=false&amp;width=450&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe></td>
        </tr>
    </table>
  </div>


                </td>

              </tr>

            </table>

          </td>

        </tr>

      </table>

    </td>

  </tr>

</table>

</td>

<?php $stats = new User_Stats("bang"); ?>

<table class="top">
	<tr>
		<td align="left" valign="bottom">
			&copy;2010-2013 All Rights Reserved With DBG
        </td>
	</tr>
	</table>



</body>

</html>
<?
ob_end_flush();
?>