<?php

$GLOBALS['pdo'] = new PDO('mysql:dbname=popkwgxh_game;host=127.0.0.1', "popkwgxh_admin", "PKGMMW1+ro@N");

?>
