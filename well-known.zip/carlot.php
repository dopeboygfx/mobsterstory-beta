<?
include 'header.php';

if ($user_class->city != 2){
	echo Message("You must be in Los Angeles to visit Big Bob's. If you are level 5 you can take the <a href='bus.php'>bus</a> to L.A. now and visit Big Bob's.");
	include 'footer.php';
	die();
}

if (isset($_GET['buy'])) {

$resultnew = $GLOBALS['pdo']->prepare('SELECT * from `carlot` WHERE `id` = ?');
$resultnew->execute(array($_GET['buy']));
$worked = $resultnew->fetch(PDO::FETCH_ASSOC);

 if($worked['id'] != ""){
    if ($user_class->money >= $worked['cost']){
    $newmoney = $user_class->money - $worked['cost'];

	$newsql = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `money` = ? WHERE `id` = ?');
	$newsql->execute(array($newmoney, $user_class->id));

	$result = $GLOBALS['pdo']->prepare('INSERT INTO `cars` VALUES(?, ?)');
	$result->execute(array($user_class->id, $_GET['buy']));

    echo Message("You have purchased a ".$worked['name']);
    } else {
    echo Message("You do not have enough money to buy a ".$worked['name']);
    }
  } else {
  echo Message("That isn't a real item.");
  }
}

$result = $GLOBALS['pdo']->query('SELECT * FROM `carlot`');
$result = $result->fetchAll(PDO::FETCH_ASSOC);
$howmanyitems = 0;
foreach($result as $line){
	if ($line['buyable'] == 1){
		$cars .= "	
		<td width='25%' align='center'>
	
						<img src='". $line['image']."' width='100' height='100' style='border: 1px solid #333333'><br>
						". car_popup($line['name'], $line['id']) ."<br>
						$". $line['cost'] ."<br>
						<a href='carlot.php?buy=".$line['id']."'>[Buy]</a>
					</td>
		";
		$howmanyitems = $howmanyitems + 1;
		if ($howmanyitems == 3){
			$cars.= "</tr><tr>";
			$howmanyitems = 0;
		}
	}
}
?>
<tr><td class="contenthead">Car Lot</td></tr>
<tr><td class="contentcontent">
Welcome to Big Bob's Used Car Lot! Just take your pick of any cars I have out in my lot.
</td></tr>
<tr><td class="contentcontent">
<table width='100%'>
				<tr>
				<? echo $cars; ?>
				</tr>
			</table>
</td></tr>
<?
include 'footer.php'
?>
