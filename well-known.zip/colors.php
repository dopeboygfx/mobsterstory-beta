<?
include 'dbcon.php';
if ($_POST['submit']){
	$result = $GLOBALS['pdo']->prepare('UPDATE `styles` SET `value` = ? WHERE `style`="2" AND `colornum` = ?');
	$result->execute(array($_POST['newcolor'], $_POST['colornum']));
}
// get style info
$cresult = $GLOBALS['pdo']->query('SELECT * FROM `styles` WHERE `style` = "2"');
$cresult = $cresult->fetchAll(PDO::FETCH_ASSOC);

$i = 0;
echo "<table>";
foreach($cresult as $line){
	$color[$i] = $line['value'];
	echo "<tr>";
	echo '<td style="background-color:'.$color[$i].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'.$color[$i].'</td><td><form method="post"><input type="text" name="newcolor"><input type="hidden" name="colornum" value="'.$line['colornum'].'"><input type="submit" name = "submit" value = "Change"></form>';
	$i++;
}
//get style info
?>

