<?php
/*-----------------------------------------------------
»Netcodes UK Mods
»http://www.netcodesuk.com/
»Chatroom Mod
»Licensed under the Creative Commons License, Org.
»Copyright OXIDATI0N
-------------------------------------------------------*/
include "header.php";

$name=$user_class->formattedname." [$user_class->id] : "; //The name of the user

print "<center>
<h3>Chatroom</h3>";

if($_REQUEST['message'])
{
$_GET['message'] = $_REQUEST['message'];


$mess = array("gay","shit","poo","game","sign up", "porn", "nob","cock","dick");

$found = 0; //amount of dirty words found
foreach($mess as $val)
{
if(eregi($val, $_GET['message']))
{
$found ++;

} else {

}
//filterd done

$words = array("%","^","&","*","!","?","#","@");

$rand = false;


foreach($words as $w)
{
if(strlen($rand) < 5)
{
$rand .= $w;
}


}

$_GET['message'] = str_replace($val, $rand, $_GET['message']);

}
$newtotal = $name;
$newtotal .= $_GET['message'];
$newtotal .= "/n";
if(strlen(file_get_contents("chatbox.txt")) <= 3000)
{
$f = @file_get_contents("chatbox.txt");
}
$newtotal .= $f;
$f = fopen("chatbox.txt", "w");
fwrite($f, $newtotal);
fclose($f);


}

print "<iframe frameborder='0' src='chats.php' width='100%' height='60%'>

</iframe><br />
<div id='do_a'></div><br />
<form name='newmessage' action='chat.php' method='post' onsubmit='checkbad()'>
Message: <input type='text' name='message' value='' size='30' maxlength='30'><br />
<input type='submit' id='mess' value='Add your message'>
</form>
</center>";


include(DIRNAME(__FILE__).'/footer.php');
?>