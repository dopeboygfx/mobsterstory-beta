<?php
require __DIR__.'/inc/nliheader.php';
$err = [];
if (array_key_exists('contact', $_POST)) {
    if (!csrf_check('csrf', $_POST)) {
        echo Message(SECURITY_TIMEOUT_MESSAGE);
    }
    if (empty($_POST['emaler']) || empty($_POST['subject']) || empty($_POST['message'])) {
        $err[] = "You missed a reqired input please go back and correct it. <a href='contact.php'>[Go Back]</a>";
    }
    $sender = array_key_exists('emailer', $_POST) && is_string($_POST['emailer']) ? stripslashes($_POST['emailer']) : false;
    if (!isset($sender) || !valid_email(stripslashes($sender))) {
        $err[] = "You have submitted a invalid email address.. <a href='contact.php'>[Go Back]</a>";
    }
    $subject = array_key_exists('subject', $_POST) && is_string($_POST['subject']) ? stripslashes($_POST['subject']) : false;
    if (!preg_match('/[^0-9a-zA-Z\s-]/i', $subject)) {
        $err[] = "You are only allowed numbers lowercase,uppercase spaces and (-) symbols in subject.. <a href='contact.php'>[Go Back]</a>";
    }
    if (strlen($subject) > 75 || strlen($subject) < 5) {
        $err[] = "You'r subject must be between 5 and 75 characters long.";
    }
    $message = array_key_exists('message', $_POST) && is_string($_POST['message']) ? stripslashes($_POST['message']) : false;
    if (!preg_match('/[^0-9a-zA-Z\s-]/i', $message)) {
        $err[] = "You are only allowed numbers lowercase,uppercase spaces and (-) symbols in message.. <a href='contact.php'>[Go Back]</a>";
    }
    if (strlen($message) > 500 || strlen($message) < 10) {
        $err[] = "You'r message must be between 10 and 500 characters you used ".strlen($message)." characters.. <a href='contact.php'>[Go Back]</a>";
    }
    $message = wordwrap($message, 70);
    $headers = 'From: MobstersOnline Boss'."\r\n".'CC: mobboss@mobstersonline.com';
    $sendto = 'nonstopcoding@gmail.com';
    if (!mail($sendto, $subject, $message, $headers)) {
        $err[] = "Couldn't send that email. <a href='contact.php'>[Go Back]</a>";
    }
    if (!count($err)) {
        $db->query('INSERT INTO (email, subject, message) VALUES (?, ?, ?)');
        $db->execute([$sender, $subject, $message]);
        mail($sendto, $subject, $message, $headers);
        echo Message("Your email has been sent to the main owner. He will reply shortly! <a href='index.php'>Login</a>");
    } else {
        display_errors($errors);
    }
} ?>
<tr>
    <th class="content-head">Contact Form</th>
</tr>
<tr>
    <td class="content">
        <form action="contact.php" method="post" class="pure-form pure-form-aligned">
            <?php echo csrf_create('csrf'); ?>
            <table width="85%" cellspacing="0" cellspading="1">
                <tr>
                    <td>
                        <div class="pure-control-group">
                            <label for="username">Email:</label>
                            <input type="email" name="emailer" id="username" size="22" required autofocus />
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="pure-control-group">
                            <label for="username">Subject:</label>
                            <input type="text" name="subject" id="username" size="22" required />
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="pure-control-group">
                            <label for="username">Your Message:</label>
                            <textarea class="textarea" name="message" rows="5" cols="15">

                        </textarea>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="pure-controls">
                            <button type="submit" name="contact" class="pure-button pure-button-primary">Send Email to Game Owner</button>
                        </div>
                    </td>
                </tr>
            </table>
        </form>
    </td>
</tr>
<?php
include __DIR__.'/inc/nlifooter.php';
