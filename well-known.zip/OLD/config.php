<?php
	// Turn off in production
	ini_set('display_errors', 'on');
	
	// If true, debug information is displayed when commiting crimes.
	// Set to false in production
	define('CRIME_DEBUG', true);

	// Register globals - please make sure this is disabled
	if (ini_get('register_globals') != false) die('Please turn off <b>register_globals</b>...');
	
	// Base URL without the trailing slash
	define('BASE_URL', 'http://example.com');

	// Database settings
	define('DB_HOST', 'localhost');
	define('DB_USER', 'popkwgxh_twolucky');
	define('DB_PASS', 'Winter2018');
	define('DB_NAME', 'popkwgxh_popkul');
	// Leave blank unless you want to use the same database and would need to prefix the scripts tablenames to prevent conflicts/errors etc.
	define('DB_PREF', '');

	// Timezone settings
	define('APPLICATION_TIMEZONE', 'US/Eastern');
	define('DATABASE_TIMEZONE', '+0:00');

	// reCAPTCHA key
	// Make sure you also enter the public and private keys in templates/index.html on lines 126-130
	define('RECAPTCHA_PUBLIC_KEY', '6LeRpfESAAAAAFpHuJeNzGMCzaR9-qti8ytE0X4S ');
	define('RECAPTCHA_PRIVATE_KEY', '6LeRpfESAAAAAC5vv4szUVGkFfPxeTe25zWkTcFC');

	// Cronjob security layers (don't use special chars only alphanum)
	define('CRON_SECURITY_TOKEN', 'G7470E3TST');
	define('CRON_INTERVAL_DISCREPANCY', '5'); // in seconds

	// PayPal settings
	define('PAYPAL_SANDBOX_MODE', 0); // Change to 1 if testing! Add your email.
	define('PAYPAL_MERCHANT_EMAIL', '');
	define('PAYPAL_CURRENCY', 'USD');

	// An extar layer of protection (random and long please)
	define('PASSWORD_SALT', 'ENTER PASSWORD SALT HERE');
	define('AVATAR_SALT', 'ENTER AVATAR SALT HERE');

	// Seconds of inactivity to log the user out
	define('ACTIVITY_TIMEOUT', TICK_MINUTE * 5);

	// Error settings (LOG_LEVEL_DISPLAY, LOG_LEVEL_FILE, LOG_LEVEL_MAIL)
	// Combine as bitmask
	define('ERROR_LEVEL_NOTICE', LOG_LEVEL_DISPLAY);
	define('ERROR_LEVEL_CRITICAL', LOG_LEVEL_DISPLAY);
	define('ERROR_LOG_FILE', 'error.log');
	define('ERROR_LOG_EMAIL', 'admin@localhost');

	// Messages Reply prefix
	define('REPLY_PREFIX', 'Re: ');

	// Stats percentages precision
	define('STATS_PRECISION', 0);

	// E-mail configuration
	define('MAIL_FROM', 'info@example.com');
	define('MAIL_SUBJECT_PREFIX', '[MyWebsite]');
	define('MAIL_SUBJECT_NOSUBJECT', MAIL_SUBJECT_PREFIX.' No subject');
	define('MAIL_SUBJECT_ACTIVATION', MAIL_SUBJECT_PREFIX.' Please activate your account');
	define('MAIL_SUBJECT_FORGOT_PWD', MAIL_SUBJECT_PREFIX.' Your password has been reset');
	define('MAIL_SUBJECT_WELCOME', MAIL_SUBJECT_PREFIX.' Welcome');
	define('MAIL_SUBJECT_NEW_MESSAGE', MAIL_SUBJECT_PREFIX.' Someone sent you a message');
	define('MAIL_SUBJECT_CONTACT_ADD', MAIL_SUBJECT_PREFIX.' Someone has added you to their contacts');
	define('MAIL_SUBJECT_CONTACT_DEL', MAIL_SUBJECT_PREFIX.' Someone has removed you from their contacts');
	define('MAIL_SUBJECT_DELIVERY', MAIL_SUBJECT_PREFIX.' Your purchase has been delivered');
	define('MAIL_SUBJECT_ROLECHANGE', MAIL_SUBJECT_PREFIX.' Your account role has been modified');

	// Forum settings
	define('FORUM_OBJECTS_PER_PAGE', 10);

	// Admin settings
	define('ADMIN_MESSAGES_PER_PAGE', 25);

	// Game settings
	define('MAX_CRIME_PER_CITY', 20);
	define('ENERGY_COST', 10);
	define('HOUSE_PER_LOCATION', 250);
	define('PROSTITUTE_PER_LOCATION', 100);
	define('BUSINESS_PER_LOCATION', 100);
	define('TURF_OWNAGE_PERCENTAGE', 0.01);
	define('MAX_DEALER_PER_PUB', 10);
	define('DEALER_EXPIRES', TICK_MINUTE * 10);
	define('PIP_DEAD_BODYGUARD', 25000);
	define('GENERATE_CRIME_COST', 30);
	define('SUBSCRIPTION_PERIOD', 30);

	// Once every 24 hours
	define('VOTE_INTERVAL', TICK_HOUR * 24);

	define('REFERRAL_TOKENS', 500);
	define('REFERRAL_RANK', RANK_EARNER);

	define('SLOTS_ALL_MATCH_PROBABILITY', 5);
	define('SLOTS_SIDES_MATCH_PROBABILITY', 20);
	define('SLOTS_TWO_MATCH_PROBABILITY', 30);
?>
