<?php
include 'header.php';
?>
<tr><td class="contenthead">Respected Mobsters</td></tr>
<tr><td style="text-align: center;" class="contentcontent">
	<center>
<table>
	
  <tr>
    <th>30 Day Respected Mobster |</th>
    <th>60 Day Respected Mobster |</th>
    <th>90 Day Respected Mobster</th>
  </tr>
  <tr>
    <td>Double Bank Interest</td>
    <td>Double Bank Interest</td>
    <td>Double Bank Interest</td>
  </tr>
  <tr>
    <td>250 Points - One Time</td>
    <td>350 Points - One Time</td>
    <td>450 Points - One Time </td>
  </tr>
  <tr>
    <td>$15,000</td>
    <td>$25,000</td>
    <td>$35,000</td>
  </tr>
  <tr>
    <td>Awake Pill</td>
    <td>Awake Pill</td>
    <td>Awake Pill</td>
  </tr>
  <tr>
    <td>x2 Energy Regenerate Time </td>
    <td>x2 Energy Regenerate Time </td>
    <td>x2 Energy Regenerate Time </td>
  </tr>
  <tr>
    <td>x2 Nerve Regenerate Time</td>
    <td>x2 Nerve Regenerate Time</td>
    <td>x2 Nerve Regenerate Time</td>
  </tr>
    <tr>
    <td>Drug Dealer Access</td>
    <td>Drug Dealer Access</td>
    <td>Drug Dealer Access</td>
  </tr>
    <tr>
    <td>Mission Access</td>
    <td>Mission Access</td>
    <td>Mission Access</td>
  </tr>
  <tr>
	  <td>
	  </br>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="R8SHFGYEGM42E">
		<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay 		online!">
		<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
	  </td>
	  <td>
		  	  </br>
		  <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="VZ67CP9KWWXE6">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

	  </td>
	  <td>
	  </br>
	  <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="XSDVAR74TNASS">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

	  </td>
  </tr>
</table>
</center>
<h2><font color="red">Please beware that Mobster Story is in BETA. Therefore anything you buy now will not be transferrable. Buy Thank you .. Dopeboy</font></h2>
	<a href="#">Guide - Coming Soon!</a>
	</td></tr>
	

	
	
	<tr><td class='contenthead'>Featured Weapon of the Month</tr></td>
	<tr>
	  <td class='contentcontent'><center>
		  S.W.A.T VEST<br />
		  Limited Quantity: 10 Count<br />
		  Defence Bonus: 66%<br />
		  Rarity: Super Rare<br />

		  
	    <br /><center>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="9ZFNQ8DY6AJJN">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

</center></td></tr>
	<tr><td class="contenthead">Premium Add-Ons</td></tr>
	<tr><td class="contentcontent">
	<table width='100%'>
<tr>

	<th>Package</th>
	<td>RM Days</td>
	<td>Money</td>
	<td>Points</td>
	<td>Items</td>
	<td>Cost</td>
	<td>Buy</td>
</tr>

	<tr>
		<td>250 Point Pack</td>
		<td>-</td>
		<td>-</td>

		<td>250</td>
		<td>-</td>
		<td>$3.00 ($0.012 per point)</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="R8SHFGYEGM42E">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
		</td>
	</tr>
	<tr>
		<td>1000 Points Pack</td>
		<td>-</td>
		<td>-</td>

		<td>1000</td>
		<td>-</td>
		<td>$10.00 ($0.01 per point)</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="MQEV7ZUKMCNXQ">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
		</td>
	</tr>
	<tr>
		<td>5,000 Points Pack</td>
		<td>-</td>
		<td>-</td>

		<td>5,000</td>
		<td>-</td>
		<td>$30.00 ($0.006 per point)</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="A4YNPNRPHNZKW">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
	</tr>
	<tr>
		<td>Prostitutes</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>$0.50 (They make you $300 a night!)</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="3UVH3GN7Q7TF6">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
	</tr>
<tr>
		<td>5 Awake Pills</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>$3.00</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="2Q624GNTE5ZFU">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</tr>
<tr>
		<td>25 Awake Pills</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>$11.00</td>
		<td>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="K92EJNCLMUQ8A">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</tr>
	</table>
</td><tr>
<tr><td class="contenthead">Read This Or Die</td></tr>
<tr><td class="contentcontent">
	If you have any questions, PM me (Dopeboy).<br>
	Before you buy you must be clear of the following things:<br><br>
	1. No refunds.<br>
	2. You can still be banned for breaking the rules whether you have donated or not.
</td></tr>
<?php
include 'footer.php';
?>

