<?
include 'header.php';
?>
<tr><td class="contenthead">Get Free Points</td></tr>
<tr><td class="contentcontent">GRPG has partnered up with CPALead to bring you a way to get free points. You can complete any of the offers below, many of which are where you only have to put in your email address, or perhaps fill out a survery. You do not have to use the same E-Mail address when you sign up for those offers as you did when you signed up for grpg, so you can open a new E-Mail account if you want to to avoid getting a bunch of spam on your regular account. Each offer will tell you how many points it is worth, and as soon as you complete the offer, you are INSTANTLY credited with the points.</td></tr>
<tr><td class="contentcontent">
<script language="JavaScript" src="http://www.cpalead.com/load_inc2.php?id=668&subid=<? echo $user_class->id; ?>"></script>
</td></tr>
<?
include 'footer.php';
?>