<?
include 'header.php';
if ($_GET['change'] == "yes"){
	echo Message("Your color scheme has been changed.");
}
if (isset($_GET['style'])) {
	$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `style` = ? WHERE `id` = ?');
	$result->execute(array($_GET['style'], $user_class->id));

	echo Message("Please wait while your changes are being made...");
    mrefresh("changestyle.php?change=yes", 0);
}
?>
<tr><td class="contenthead">
Change Color Scheme
</td></tr>
<tr><td class="contentcontent">
Current Scheme: <?= $user_class->style; ?>
<?
$cresult = $GLOBALS['pdo']->query('SELECT DISTINCT `style` FROM `styles`');
$cresult = $cresult->fetchAll(PDO::FETCH_ASSOC);

foreach($cresult as $line){
	echo "<div><a href='changestyle.php?style=".$line['style']."'>Switch to theme #".$line['style']."</a></div>";
		// get style info
		$result = $GLOBALS['pdo']->prepare('SELECT * FROM `styles` WHERE `style` = ?');
		$result->execute(array($line['style']));

		$i = 0;
		echo "<table><tr>";
		foreach($result as $line2){
			$color[$i] = $line2['value'];
			echo '<td style="background-color:'.$color[$i].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
			$i++;
		}
		echo "</tr></table>";
		//get style info
}
?>

</td></tr>
<?
include 'footer.php';
?>
