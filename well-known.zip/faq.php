<?php
include 'header.php';
?>
<u>FAQ</u><br>
Q.) What does next HEAN and next Jail/Hospital Update mean?<br>
A.) HEAN stands for HP Energy Awake Nerve. Every 5 minutes, those things will go up a little bit (the amount depends on whether you are a regular player or a respected mobster). The Jail/Hospital Updated happens every 1 minute, and reduces everybody's jail time and hospital time by 1 minute.
<?php
include 'footer.php';
?>