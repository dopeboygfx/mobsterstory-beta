<?
include 'dbcon.php';

$result = $GLOBALS['pdo']->query('SELECT * FROM `inventory` ORDER BY `userid` DESC');
$result = $result->fetchAll(PDO::FETCH_ASSOC);
$howmanytotal = count($result);

foreach($result as $line){
	$result2 = $GLOBALS['pdo']->prepare('SELECT * FROM `inventory` WHERE `userid` = ? AND `itemid` = ?');
	$result2->execute(array($line['userid'], $line['itemid']));
	$result2 = $result2->fetchAll(PDO::FETCH_ASSOC);

	$howmanyrows = count($result2);
	$worked2 = $result2[0];

	if($howmanyrows>0){
		$result3 = $GLOBALS['pdo']->prepare('INSERT INTO `newinventory` (userid, itemid, quantity) VALUES (?, ?, ?)');
		$result3->execute(array($line['userid'], $line['itemid'], $howmanyrows));

		$result4 = $GLOBALS['pdo']->prepare('DELETE FROM `inventory` WHERE `userid` = ? AND `itemid` = ?');
		$result4->execute(array($line['userid'], $line['itemid']));
	}
}

?>
