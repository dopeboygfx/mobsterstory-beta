<?
include 'header.php';

if ($_GET['buy'] == "ticket"){
	$checklotto = $GLOBALS['pdo']->prepare('SELECT * FROM `lottery` WHERE `userid` = ?');
	$checklotto->execute(array($user_class->id));
	$numlotto = count($checklotto->fetchAll(PDO::FETCH_NUM));

	if ($numlotto >= 5) {
		$error = "You have already bought 5 tickets today.";
	}
	if ($user_class->money < 1000){
		$error = "You don't have enough money to buy any tickets.";
	}
	if ($error == "") {
		$newmoney = $user_class->money - 1000;

		$result = $GLOBALS['pdo']->prepare('INSERT INTO `lottery` (userid) VALUES (?)');
		$result->execute(array($user_class->id));

		$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `money` = ? WHERE `id`= ?');
		$result->execute(array($newmoney, $user_class->id));

		echo Message("You have bought a lottery ticket.");
	} else {
		echo Message($error);
	}
}
?>
<thead>
<tr>
<th>Daily Lottery</th>
</tr>
</thead>
<tr><td>
Do you want to buy a ticket for the daily lottery? You can buy up to 5 tickets a day for $1000 a ticket. The more people that enter, the more that the winner will win. If your ticket is drawn at the end of the day, you win 75% of the ticket revenue!
<br><br><button class="ui mini blue button"><a href="lottery.php?buy=ticket"><font color="white">Buy Ticket</font></a></button>
</td></tr>
<tr><td>
<?

$checklotto = $GLOBALS['pdo']->query('SELECT * FROM `lottery`');
$numlotto = count($checklotto->fetchAll(PDO::FETCH_NUM));

$amountlotto = $numlotto * 750;
echo "There have been ".$numlotto." Lotto Tickets bought today.<br>";
echo "Lotto is currently worth $".$amountlotto;
echo '</td></tr>';
include 'footer.php';
?>
