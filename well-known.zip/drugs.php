<?php

include 'header.php';

if ($_GET['use'] == "cocaine") {
	$checkeffects = $GLOBALS['pdo']->prepare('SELECT * FROM `effects` WHERE `userid` = ?');
	$checkeffects->execute(array($user_class->id));
	$numeffects = count($checkeffects->fetchAll(PDO::FETCH_NUM));

	$error = ($numeffects > 0) ? "You already have an effect!" : $error;
	$error = ($user_class->cocaine == 0) ? "You do not have any cocaine." : $error;

	if (isset($error)){
		echo Message($error);
		include 'footer.php';
		die();
	}

	$newamount = $user_class->cocaine - 1;

	$newsql = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `cocaine` = ? WHERE `id`= ');
	$newsql->execute(array($newamount, $user_class->id));

	echo Message("You snorted some cocaine.");

	$result = $GLOBALS['pdo']->prepare('INSERT INTO `effects` (`userid`, `effect`, `timeleft`) VALUES (?, "Cocaine", "15")');
	$result->execute(array($user_class->id));
}

if ($_GET['use'] == "genericsteroids") {
	$checkeffects = $GLOBALS['pdo']->prepare('SELECT * FROM `effects` WHERE `userid` = ?');
	$checkeffects->execute(array($user_class->id));
	$numeffects = count($checkeffects->fetchAll(PDO::FETCH_NUM));

	$error = ($numeffects > 0) ? "You already have an effect!" : $error;
	$error = ($user_class->genericsteroids == 0) ? "You do not have any Steroids." : $error;

	if (isset($error)){
		echo Message($error);
		include 'footer.php';
		die();
	}

	$newamount = $user_class->genericsteroids - 1;

	$newsql = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `genericsteroids` = ? WHERE `id`= ?');
	$newsql->execute(array($newamount, $user_class->id));

	echo Message("You popped some Steroids.");

	$result = $GLOBALS['pdo']->prepare('INSERT INTO `effects` (`userid`, `effect`, `timeleft`) VALUES (?, "Generic Steroids", "15")');
	$result->execute(array($user_class->id));
}

if ($_GET['use'] == "nodoze") {
	$error = ($user_class->nodoze == 0) ? "You do not have any No-Doze." : $error;

	if (isset($error)){
		echo Message($error);
		include 'footer.php';
		die();
	}

	$newamount = $user_class->nodoze - 1;
	$newawake = $user_class->awake + 50;
	$newawake = ($newawake > $user_class->maxawake) ? $user_class->maxawake : $newawake;

	$newsql->prepare('UPDATE `grpgusers` SET `nodoze` = ?, `awake` = ? WHERE `id`= ?');
	$newsql->execute(array($newamount, $newawake, $user_class->id));

	echo Message("You popped some No-Doze.");
}

include 'footer.php';

?>
