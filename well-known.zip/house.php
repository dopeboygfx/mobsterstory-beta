<?php
include 'header.php';

if($_GET['buy'] != ''){
	$result = $GLOBALS['pdo']->prepare('SELECT * FROM `houses` WHERE `id` = ?');
	$result->execute(array($_GET['buy']));
	$worked = $result->fetch(PDO::FETCH_ASSOC);

    $cost = $worked['cost'];
	if($user_class->house != 0){
		$result2 = $GLOBALS['pdo']->prepare('SELECT * FROM `houses` WHERE `id` = ?');
		$result2->execute(array($user_class->house));
		$worked2 = $result2->fetch(PDO::FETCH_ASSOC);

		$cost = $cost - ($worked2['cost'] * .75);
	}
	
	if($cost > $user_class->money){
		echo Message("You don't have enough money to buy that house.");
	}

	if($cost <= $user_class->money && $worked['name'] != ""){
		$newmoney = $user_class->money - $cost;

		$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `house` = ?, `money` = ? WHERE `id` = ?');
		$result->execute(array($_GET['buy'], $newmoney, $_SESSION['id']));

		echo Message('You have sold your house for 75% of what it was worth ($'.$cost."). That amount will go towards the purchase of the new house.");
		echo Message("You have purchased and moved into ".$worked['name'].".");
		$user_class = new User($_SESSION['id']);
	}

	if ($worked['name'] == ""){
		echo Message("That's not a real house.");
	}
}

if($_GET['action'] == 'sell'){
	$result = $GLOBALS['pdo']->prepare('SELECT * FROM `houses` WHERE `id` = ?');
	$result->execute(array($user_class->house));
	$worked = $result->fetch(PDO::FETCH_ASSOC);

    $cost = $worked['cost'] * .75;
	if($user_class->house == 0){
		echo Message("You live on the streets already.");
		exit;
	}else{
		$result2->prepare('SELECT * FROM `houses` WHERE `id` = ?');
		$result2->execute(array($user_class->house));
		$worked2 = $result2->fetch(PDO::FETCH_ASSOC);

		$cost = $worked['cost'] * .75;
		$newmoney = $user_class->money + $cost;

		$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `house` = 0, `money` = ? WHERE `id` = ?');
		$result->execute(array($newmoney, $_SESSION['id']));

		$user_class = new User($_SESSION['id']);
		echo Message('You have sold your house for 75% of what it was worth ($'.$cost.").");
	}
}


?>
<thead>
<tr>
<th>Move House</th>
<th> </th>
<th> </th>
<th> </th>
</tr>
</thead>
<?
if($user_class->house > 0){
	echo "<tr><td><a href='house.php?action=sell'>Sell Your House</a></td></tr>";
}
?>
	<tr>
		<td width='45%'><b>Type</b></td>
		<td width='15%'><b>Awake</b></td>
		<td width='20%'><b>Cost</b></td>
		<td width='20%'><b>Move</b></td>
	</tr>

<?php
$result = $GLOBALS['pdo']->query('SELECT * FROM `houses` ORDER BY `id` ASC');
$result = $result->fetchAll(PDO::FETCH_ASSOC);

foreach($result as $line){
	echo "<tr><td width='45%'>".$line['name']."</td><td>".$line['awake']."</td><td>\$".$line['cost']."</td><td>";
	if($line['id'] > $user_class->house){
		echo "<a href='house.php?buy=".$line['id']."'>Move In</a>";
	}
	echo "</td></tr>";
}
?>
</table>
</td></tr>
<?php
include 'footer.php';
?>
