<?
include 'header.php';
?>
<thead>
<tr>
<th>Staff Members</th>
</tr>
</thead>
<tr><td>
<a href="profiles.php?id=1">Dopeboy</a> - Mobster Story Founder<br>
<a href="profiles.php?id=2">Coder</a> - Developer
</td></tr>
<?
include 'footer.php';
?>