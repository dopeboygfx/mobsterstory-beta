<?
include 'header.php';

$result = $GLOBALS['pdo']->prepare('SELECT * FROM `cars` WHERE `userid` = ?');
$result->execute(array($user_class->id));
$howmany = count($result->fetchAll(PDO::FETCH_NUM));

if($howmany == 0){
	echo Message("You don't have a car. You can't drive without a car.");
	include 'footer.php';
	die();
}

if($_GET['go'] != ""){
	$result = $GLOBALS['pdo']->prepare('SELECT * FROM `cars` WHERE `userid` = ?');
	$result->execute(array($user_class->id));
	$howmany = count($result->fetchAll(PDO::FETCH_NUM));

	$error = ($howmany ==0) ? "You don't have a car. You can't drive somewhere without a car." : $error;
	$error = ($user_class->jail > 0) ? "You can't drive somewhere if you are in jail." : $error;
	$error = ($user_class->hospital > 0) ? "You can't drive somewhere if you are in the hospital." : $error;
	$error = ($_GET['go'] == $user_class->city) ? "You are already there." : $error;

	$result = $GLOBALS['pdo']->prepare('SELECT * FROM `cities` WHERE `id` = ?');
	$result->execute(array($_GET['go']));
	$worked = $result->fetch(PDO::FETCH_ASSOC);

	$error = ($worked['name'] == "") ? "That city doesn't exist." : $error;
	$error = ($user_class->level < $worked['levelreq']) ? "You are not a high enough level to go there." : $error;
	$error = ($user_class->money < 50) ? "You can't afford gas." : $error;

	$checkDrugs = $GLOBALS['pdo']->prepare('SELECT * FROM `drugstorage` WHERE `userid` = ?');
	$checkDrugs->execute(array($user_class->id));
	$countDrugs = count($checkDrugs->fetchAll(PDO::FETCH_NUM));

	if($countDrugs > 0){
		//if they have drugs on them.
		$rand = mt_rand(1,100);
		if($rand > 75){
			//send user to jail! for 20mins
			//update database here

			$update = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `jail` = 1200 WHERE `id` = ?');
			$update->execute(array($user_class->id));

			$removedrugs = $GLOBALS['pdo']->prepare('DELETE FROM `drugstorage` WHERE `userid` = ?');
			$removedrugs->execute(array($user_class->id));

			echo Message("You have been caught smuggling items. you have been sent to jail for 20 minutes.");
			include(DIRNAME(__FILE__).'/footer.php');
			exit;
		}
	}

	if(!isset($error)){
		$newmoney = $user_class->money - 50;

		$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `city` = ?, `money` = ? WHERE `id` = ?');
		$result->execute(array($_GET['go'], $newmoney, $user_class->id));

		$user_class = new User($_SESSION['id']);
		echo Message("You successfully paid $50 for gas and drove to your destination.");
	}
} 
?>
	 <thead>
	    <tr>
		<th>Drive</th>
  		</tr>
  		</thead>
	<tr><td>Tired of <?= $user_class->cityname ?>? Pay $50 for gas for your car and you can drive anywhere you want.

	</td></tr>
<?

$result = $GLOBALS['pdo']->query('SELECT * FROM `cities` ORDER BY `levelreq` ASC');
$result = $result->fetchAll(PDO::FETCH_ASSOC);

echo '<tr><td>';

foreach($result as $line){
	echo "<div>".$line['name'] . " Lvl Req:".$line['levelreq']." <a href='drive.php?go=".$line['id']."'>Drive</a></div>";
}

echo '</td></tr>';

include 'footer.php';
?>
