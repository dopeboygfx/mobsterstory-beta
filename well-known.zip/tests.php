<?php
/* 01-16-2014 - G7470 Programming in association with Steve Modifications -  Added text checks to make input more secure. */
include 'gmheader.php';
//$check1 = $GLOBALS['pdo']->prepare("SELECT * FROM `grpgusers` WHERE `id` = ?");
//$check1->execute(array($_GET['id']));
//$check = $check1->fetchALL(PDO::FETCH_ASSOC);
//if(count($check) < 1) {
	//echo Message("This player doesn't exist.");
	
//}

include 'footer.php';
