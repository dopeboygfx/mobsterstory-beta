<?php

include 'header.php';

if ($_GET['buy']){
	$result = $GLOBALS['pdo']->prepare('SELECT * FROM `itemmarket` WHERE `id` = ?');
	$result->execute(array($_GET['buy']));
	$worked = $result->fetch(PDO::FETCH_ASSOC);

	$result2 = $GLOBALS['pdo']->prepare('SELECT * FROM `items` WHERE `id` = ?');
	$result2->execute(array($worked['itemid']));
	$worked2 = $result2->fetch(PDO::FETCH_ASSOC);

    $price = $worked['cost'];
 	$user_item = new User($worked['userid']);

	if ($worked['userid'] == $user_class->id) {
		echo Message("You have taken your ".$worked2['itemname']." off the market.");
		Give_Item($worked2['id'], $user_class->id);//give them the item they bought

		$result = $GLOBALS['pdo']->prepare('DELETE FROM `itemmarket` WHERE `id` = ?');
		$result->execute(array($_GET['buy']));

		include 'footer.php';
		die();
	}

	if ($price > $user_class->money){
		echo Message("You don't have enough money.");
	}else {
		echo Message("You have bought a ".$worked2['itemname'].".");
		$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `money` = ? WHERE `id` = ?');

		$newmoney = $user_class->money - $price;
		$result->execute(array($newmoney, $user_class->id));

		$newmoney = $user_item->money + $price;
		$result->execute(array($newmoney, $user_item->id));

		$user_class = new User($_SESSION['id']);

		$result = $GLOBALS['pdo']->prepare('DELETE FROM `itemmarket` WHERE `id` = ?');
		$result->execute(array($_GET['buy']));

		Give_Item($worked2['id'], $user_class->id);//give them the item they bought
	}
}

?>
		<thead>
	    <tr>
		<th>Item Market</th>		
  		</tr>
  		</thead>

<tr><td>

<?php

$result = $GLOBALS['pdo']->query('SELECT * FROM `itemmarket` ORDER BY `cost` ASC');
$result = $result->fetchAll(PDO::FETCH_ASSOC);

foreach($result as $line){
	$user_item = new User($line['userid']);

	$result2 = $GLOBALS['pdo']->prepare('SELECT * FROM `items` WHERE `id` = ?');
	$result2->execute(array($line['itemid']));
	$worked = $result2->fetch(PDO::FETCH_ASSOC);

	if ($user_item->id == $user_class->id){
		$submittext = "Remove Item";
	} else {
		$submittext = "<button class='ui green mini button'>Buy</button>";
	}

	echo "<a href='itemmarket.php?buy=".$line['id']."'>".$submittext."</a> ".$worked['itemname']." - $".$line['cost']." from $user_item->formattedname <br>";
}

?>

</td></tr>

<?php

include 'footer.php';

?>
