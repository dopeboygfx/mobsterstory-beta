<?php
include 'header.php';

	if(isset($_POST['submit'])) {
		$_POST['username'] = strip_tags($_POST['username']);
		$checkuser = $GLOBALS['pdo']->prepare('SELECT * FROM `grpgusers` WHERE `username` = ?');
		$checkuser->execute(array($_POST['username']));

  if(!empty($checkuser->fetch(PDO::FETCH_NUM))){
    $message .= "<div>Username already taken.</div>";
  }

  //insert the values
  if(!isset($message)){
  	$result = $GLOBALS['pdo']->prepare('UPDATE `grpgusers` SET `username` = ? WHERE `id` = ?');
	$result->execute(array($_POST['username'], $user_class->id));

    echo Message('Your username has been changed.');
    
	exit;
  }
}
?>
<?
if (isset($message)) {
echo Message($message);
}
?>
<tr><td class="contenthead">
Change username
</td></tr>
<tr><td class="contentcontent">
<form name='submit' method='post'>
  <table width='25%' border='0' align='center' cellpadding='0' cellspacing='0'>
    <tr>
      <td height='28'><font size='2' face='verdana'>New username</font></td>
      <td><font size='2' face='verdana'>
        <input type='text' name='username'>
        </font></td>
    </tr>

      <td>&nbsp;</td>
      <td><font size='2' face='verdana'>
        <input type='submit' name='submit' value='Submit'>
        </font></td>
    </tr>
</table>
</form>
<?
include 'footer.php';
?>
