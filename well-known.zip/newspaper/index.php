<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>GRPG Daily Herald</title>
<link rel="STYLESHEET" href="style.css" type="text/css">
</head>
<body bgcolor="FFFFFF">
<div align="center">
<table width="750" border="0" cellpadding="0" cellspacing="0">
 <tr>
  <td colspan="3" width="750">
   <table width="750" border="0" cellpadding="0" cellspacing="0">
    <tr>
     <td width="750" colspan="3">
     <span style="font-size:28px;color:FFBA27">
     GRPG Daily Herald </span></td>
    </tr>
    <tr>
     <td width="330">August 12, 2007 </td>
      <td width="20"></td>
     <td width="400" align="left">$1.25 Daily </td>
    </tr>
   </table>  </td>
 </tr>
 <tr>
  <td colspan="3" height="15" bgcolor="FFFFFF"></td>
 </tr>
 <tr>
  <td colspan="3" height="1" bgcolor="CCCCCC"></td>
 </tr>
 <tr>
  <td colspan="3" height="10" bgcolor="FFFFFF"></td>
 </tr>
 <tr>
  <td width="750" valign="top">
  <span style="font-size:6px"><br></span>
  <div align="left">
   <table width="549" border="0" cellpadding="0" cellspacing="0">
    <tr>
     <td colspan="4" height="1" bgcolor="AAAAAA"></td>
     <td width="5" height="1" bgcolor="FFFFFF"></td>
    </tr>
    <tr>
     <td width="1" bgcolor="AAAAAA"></td>
     <td rowspan="2" colspan="2" width="542" height="27" bgcolor="F9F9F9" style="color:FFBA27;font-size:15px">&nbsp;&nbsp;Resident Millionaire / Business Tycoon / Drug Lord BUSTED! by Publius </td>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="5" height="4" bgcolor="FFFFFF"></td>
    </tr>
    <tr>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="5" bgcolor="F0F0F0" height="23"></td>
    </tr>
    <tr>
     <td width="1" bgcolor="AAAAAA"></td>
     <td colspan="2" height="1" bgcolor="AAAAAA"></td>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
     <td width="1" bgcolor="AAAAAA"></td>
     <td colspan="2" bgcolor="FFFFFF">
      <table width="542" border="0" cellpadding="17" cellspacing="0">
       <tr>
        <td style="color:999999;line-height:1.6em">
        <div align="justify">Just one week after buying all the land in Generica, the most hated yet respected man in Generica has been busted for selling drugs. After turning his newly acquired land into the basis of his new large-scale drug manufactoring operation, he planted acres upon acres of marijuana and harvested it a week later. He then proceeded to go in person to sell his green sticky gold downtown. Luckily for the youth of Generica, the local police force had already learned of this (how do you hide that many acres of pot?), and set up a sting operation to catch him in the act. When senatorhades attempted to sell the marijuana to the undercover police officer, he lost his weed, and gained a pair of handcuffs. He was hauled off to the local jail and was being held until trial, however he has recently dissapeared from the prison. It is unknown whether someone busted him out, or if he escaped on his own.</div>        </td>
       </tr>
      </table>     </td>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
     <td width="1" bgcolor="AAAAAA"></td>
     <td colspan="2" height="1" bgcolor="AAAAAA"></td>
     <td width="1" bgcolor="AAAAAA"></td>
     <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
     <td width="1" height="5" bgcolor="FFFFFF"></td>
     <td width="4" height="5" bgcolor="FFFFFF"></td>
     <td width="538" height="5" bgcolor="F0F0F0"></td>
     <td width="1" height="5" bgcolor="F0F0F0"></td>
     <td width="5" height="5" bgcolor="F0F0F0"></td>
    </tr>
   </table>
  <br>
<br>












  <table width="549" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td colspan="4" height="1" bgcolor="AAAAAA"></td>
      <td width="5" height="1" bgcolor="FFFFFF"></td>
    </tr>
    <tr>
      <td width="1" bgcolor="AAAAAA"></td>
      <td rowspan="2" colspan="2" width="542" height="27" bgcolor="F9F9F9" style="color:FFBA27;font-size:15px"> &nbsp;&nbsp;Evacuated Cities re-opened in Generica by Conor </td>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="5" height="4" bgcolor="FFFFFF"></td>
    </tr>
    <tr>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="5" bgcolor="F0F0F0" height="23"></td>
    </tr>
    <tr>
      <td width="1" bgcolor="AAAAAA"></td>
      <td colspan="2" height="1" bgcolor="AAAAAA"></td>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
      <td width="1" bgcolor="AAAAAA"></td>
      <td colspan="2" bgcolor="FFFFFF"><table width="542" border="0" cellpadding="17" cellspacing="0">
          <tr>
            <td style="color:999999;line-height:1.6em"><div align="justify">
              <p> &nbsp; &nbsp; The Grand re-opening of Seattle and New York on the 12th of August<br>
                sparked major global interest and billions tuned into watch the never before<br>
                seen event.<br>
  &nbsp; &nbsp; After the chemical bombs dropped on New York and Seattle just over a<br>
                year ago by terrorists the two cities were finally deemed safe enough for<br>
                the public to move back into there homes. Some parts of both cities are<br>
                still under construction whilst other parts have been demolished in the last<br>
                year.The majority of the public have returned to their original homes to<br>
                find no difference except a years worth of dust but some have returned to<br>
                find their homes demolished after being titled "Dangerous". The only good<br>
                coming out of this for these families is being built brand new caravans on<br>
                large camping sites.<br>
  &nbsp; &nbsp;Business has already sprung into action with many large businesses<br>
                re-opening again, but small stores have yet to open. As read above the new,<br>
                cheap land around both cities has already been snatched up by Ex-President<br>
                and business tycoon "Senator Hades". And this land is out of the control of<br>
                the law enforcement.<br>
  &nbsp; &nbsp;But already crime has re surfaced in the cities with the robbery's and<br>
                shootings starting in the first night since re opening. Thugs already<br>
                cropping up in alleys taking a chance to mug a passer by. Can the fresh new<br>
                Law Enforcement take control? Or will crime spread in Seattle and New York<br>
                making a new violent metropolis's? Will the new cities crime rise to rival<br>
                that of New Jersey?</p>
            </div></td>
          </tr>
      </table></td>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
      <td width="1" bgcolor="AAAAAA"></td>
      <td colspan="2" height="1" bgcolor="AAAAAA"></td>
      <td width="1" bgcolor="AAAAAA"></td>
      <td width="5" bgcolor="F0F0F0"></td>
    </tr>
    <tr>
      <td width="1" height="5" bgcolor="FFFFFF"></td>
      <td width="4" height="5" bgcolor="FFFFFF"></td>
      <td width="538" height="5" bgcolor="F0F0F0"></td>
      <td width="1" height="5" bgcolor="F0F0F0"></td>
      <td width="5" height="5" bgcolor="F0F0F0"></td>
    </tr>
  </table>



















  <br>
  <span style="font-size:6px"><br>
  </span>  </div>  </td>
 </tr>


 <tr>
  <td colspan="3" bgcolor="FFFFFF" align="right">
    <div align="left">Copyright &#0169; 2007, Brandon Werner (Publius)</div></td>
 </tr>
</table>
</div>
</body>
</html>